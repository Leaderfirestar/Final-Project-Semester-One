function Bullet(x, y, d, r) {
  this.x = x;
  this.y = y;
  this.d = d;
  this.h = sin(r)
  this.k = cos(r)
  this.update = function() {
    this.y = this.y + (this.h * 8)
    this.x = this.x + (this.k * 8)
  }
  this.display = function() {
    push();
    fill('red');
    ellipse(this.x, this.y, this.d)
    pop();
  }
  this.collide = function(asteroid) {
    if ((dist(this.x, this.y, asteroid.x, asteroid.y)) < asteroid.r) {
      return true
    } else {
      return false
    }
  }
}

function keyPressed() {
  if (key == ' ')
    bullets.push(new Bullet(ship.x, ship.y, 5, ship.r))
}